import cv2
import mediapipe as mp
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
light_pin = 17
GPIO.setup(light_pin, GPIO.OUT)
GPIO.output(light_pin, GPIO.LOW)

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(min_detection_confidence=0.5, min_tracking_confidence=0.5)

cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
cap.set(cv2.CAP_PROP_FPS, 30)

light_on = False

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(frame_rgb)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            fingers_open = sum(
                [hand_landmarks.landmark[i].y < hand_landmarks.landmark[i - 2].y for i in [8, 12, 16, 20]]
            )

            if fingers_open == 4 and not light_on:
                GPIO.output(light_pin, GPIO.HIGH)
                light_on = True
                print("Light ON")
            elif fingers_open == 0 and light_on:
                GPIO.output(light_pin, GPIO.LOW)
                light_on = False
                print("Light OFF")

    cv2.imshow("Gesture Control", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
GPIO.cleanup()
