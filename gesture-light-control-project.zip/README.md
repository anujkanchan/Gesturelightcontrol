# Gesture-Based Smart Light Control using Raspberry Pi

This project uses computer vision (OpenCV + MediaPipe) to detect hand gestures in real-time and control a light using Raspberry Pi GPIO. 
Open palm turns ON the light, and a fist turns it OFF.

## Features
- Real-time hand tracking using MediaPipe
- Touchless ON/OFF control using gestures
- Low-latency performance optimized for Raspberry Pi

## Setup
Follow the instructions in `setup_instructions.md` to get started.

## Authors
- Anuj Ganesh Kanchan
- Viraj Sukhdev Kalbhor
- Yash Bandu Kalbhor
- Sandesh Sachin Kalbhor
