# Setup Instructions

## 1. Install Required Libraries

```bash
sudo apt update
pip3 install opencv-python mediapipe numpy RPi.GPIO
```

## 2. Test Your Webcam

```bash
sudo apt install fswebcam -y
fswebcam test.jpg
```

## 3. Run Test Scripts

- Run camera test:
```bash
python3 camera_test.py
```

- Run hand detection:
```bash
python3 hand_tracking.py
```

- Run final gesture control:
```bash
python3 gesture_light_control.py
```

Make sure the relay is connected to GPIO 17 and powered properly.
